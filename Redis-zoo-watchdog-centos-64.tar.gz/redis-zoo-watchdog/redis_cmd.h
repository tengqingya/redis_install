#ifndef __REDIS_CMD_H__
#define __REDIS_CMD_H__

int connectRedisServer(char const *ip, int port);
int pingRedis();
int masterRedis();
int slaveRedis(char const *master_ip, char const *master_port);

#endif /* __REDIS_CMD_H__ */
