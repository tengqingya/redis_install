#ifndef __ZOO_COMMON_H__
#define __ZOO_COMMON_H__

#include <semaphore.h>
#include <stdio.h>
#include "zookeeper/zookeeper.h"

struct ZooWatchdog;

struct FailoverOp{
	int  (*__init__)(struct ZooWatchdog *zwf,
					 char const *path,
					 char const *value, int value_len,
					 struct ACL_vector *acl);
	void (*__quit__)(struct ZooWatchdog *zwf);
	int  (*__add_node__)(struct ZooWatchdog *zwf);
	int  (*__del_node__)(struct ZooWatchdog *zwf, char const *path);
	int  (*__get_node__)(struct ZooWatchdog *zwf,
						 char const *path,
						 char *data, int *data_len,
						 struct Stat *stat);
	int  (*__failover__)(struct ZooWatchdog *zwf, char const *leader_path);
	int  (*__heartbeat__)(struct ZooWatchdog *zwf);
	void (*__run__)(struct ZooWatchdog *zwf);
};

struct ZooWatchdog{
	zhandle_t *zh;
	char const *node_group_path;
	char const *node_path;
	char  *node_path_plus_seq;
	char  *current_leader;
	char  *node_value;
	size_t node_value_len;
	struct ACL_vector const *acl;
	struct FailoverOp *op;
	
	FILE *log_stream;
	
	int service_online;            /* 1: online; 1: offline */
	int leader_reelecting;         /* 1: leader reelecting; 0: leader unchanged */
	sem_t semaphore;
};

#define add_node    op->__add_node__
#define del_node    op->__del_node__
#define get_node    op->__get_node__
#define init        op->__init__
#define quit        op->__quit__
#define failover    op->__failover__
#define heartbeat   op->__heartbeat__
#define run         op->__run__

void zooWatchdogConfig();
int  zooWatchdogConnectServer(struct ZooWatchdog *zwf, watcher_fn zk_init_watcher);
int  zooWatchdogGetLowestSeqChild(struct ZooWatchdog *zwf,
								  watcher_fn watcher,
								  void *watcherCtx,
								  char **lowest_seq_child);								 
void zooWatchdogQuit(struct ZooWatchdog *zwf);
int  zooWatchdogGetNode(struct ZooWatchdog *zwf, 
						char const *path, 
						char *data, int *data_len, 
						struct Stat *stat);
int  zooWatchdogDelNode(struct ZooWatchdog *zwf, char const *path);

#endif /* __ZOO_COMMON_H__ */ 
