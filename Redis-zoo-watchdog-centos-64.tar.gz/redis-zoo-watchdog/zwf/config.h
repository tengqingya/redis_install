/* config.h - paramater configuration file
 *
 * Copyright (C) 2012, meizu Corporation. All right reserved.
 */

#ifndef __CONFIG_H_
#define __CONFIG_H_

extern char const *g_zk_servers_list;

extern char const *g_log_file;

extern char const *g_conf_file;

void config();

#endif /* __CONFIG_H_ */
