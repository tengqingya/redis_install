#ifndef __ZOO_WATCHDOG_H__
#define __ZOO_WATCHDOG_H__

#include <stdio.h>
#include "logging.h"
#include "zoo-common.h"

struct ZooWatchdog *createZooWatchdog();

#endif /* __ZOO_WATCHDOG_H__ */ 
