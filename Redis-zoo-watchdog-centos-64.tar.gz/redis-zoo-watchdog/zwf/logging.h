#ifndef __LOGGING_H_
#define __LOGGING_H_

#include <sys/types.h>

enum LogCastType{
	LOG_MULTICAST,
	LOG_UNICAST
};

enum LogLevel{
	LOG_LEVEL_BEGIN = 0,             /* begin mark, not used */

	LOG_LEVEL_EMERG = 1,             /* emergency, highest priority. */
	LOG_LEVEL_ALERT = (1 << 1),      /* alert that must be repaired immediately. */
	LOG_LEVEL_CRIT  = (1 << 2),      /* serious status such as device error */
	LOG_LEVEL_ERR   = (1 << 3),      /* error status */
	LOG_LEVEL_WARNING = (1 << 4),    /* warning status */
	LOG_LEVEL_NOTICE  = (1 << 5),    /* normal but important status */
	LOG_LEVEL_INFO    = (1 << 6),    /* informative message */
	LOG_LEVEL_DEBUG   = (1 << 7),    /* debug message */
	
	LOG_LEVEL_END
};

u_int32_t logStr2Level(char const *log_level_str);

int setLogCastType(int type);

int getLogCastType(void); 

u_int32_t setLogCastLevel(u_int32_t level);

u_int32_t setLogCastMask(u_int32_t mask);

void setLogRecordStream(FILE *log_record);

void logging(u_int32_t priority, const char *format, ...);

#endif /* __LOGGING_H_ */
