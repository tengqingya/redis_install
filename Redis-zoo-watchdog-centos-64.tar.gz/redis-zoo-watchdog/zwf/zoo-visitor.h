#ifndef __ZOO_VISITOR_H__
#define __ZOO_VISITOR_H__

#include "logging.h"
#include "zoo-common.h"

char const *getZooWatchdogLeader();
int startZooWatchdogVisitor(char const *path);
void stopZooWatchdogVisitor();

#endif /* __ZOO_VISITOR_H__ */
