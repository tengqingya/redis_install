#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include "zwf/logging.h"
#include "hiredis/hiredis.h"
#include "redis_cmd.h"

static redisContext *g_rct = NULL;

static void logRedisReply(redisReply *reply) {
	
	if (reply == NULL) {
		return;
	}

	switch (reply->type) {
	case REDIS_REPLY_STATUS:
		logging(LOG_LEVEL_NOTICE, "Status Reply : %s\n", reply->str);
		break;
	case REDIS_REPLY_ERROR:
		logging(LOG_LEVEL_NOTICE, "Error Reply : %s\n", reply->str);
		break;
	case REDIS_REPLY_INTEGER:
		logging(LOG_LEVEL_NOTICE, "Integer Reply : %ll\n", reply->integer);
		break;
	case REDIS_REPLY_NIL:
		logging(LOG_LEVEL_NOTICE, "Nil Reply \n");
		break;
	case REDIS_REPLY_STRING:
		logging(LOG_LEVEL_NOTICE, "String Reply : %s\n", reply->str);
		break;
	case REDIS_REPLY_ARRAY:
		logging(LOG_LEVEL_NOTICE, "Array Reply (Start)\n");
		for (size_t ix = 0; ix < reply->elements; ++ ix) {
			logRedisReply(reply->element[ix]);
		}
		logging(LOG_LEVEL_NOTICE, "Array Reply (End)\n");
		break;
	default:
		logging(LOG_LEVEL_ERR, "Unknown Reply Type\n");
		break;
	}
	
	return;
}

int connectRedisServer(char const *ip, int port)
{
	struct timeval timeout = {5, 0}; /* 5 second */

	if (g_rct != NULL){
		return 0;
	}
	g_rct = redisConnectWithTimeout(ip, port, timeout);
	if (g_rct->err){
		redisFree(g_rct);
		g_rct = NULL;
		return -1;
	}
	// timeout.tv_sec = 0;
	// timeout.tv_usec = 500000;
	redisSetTimeout(g_rct, timeout);
	return 0;
}
		
int pingRedis()
{
	redisReply   *reply;
	int result;
	int timeout_retry = 3;

	for ( ; ;){
		reply = redisCommand(g_rct, "PING");
		if (reply == NULL){
			if (timeout_retry-- <= 0){
				logging(LOG_LEVEL_ERR, "Can't connect to redis server: %s.\n", g_rct->errstr);
				redisFree(g_rct);
				g_rct = NULL;
				result = -1;
				break;
			}
			continue;
		}else if (reply->type == REDIS_REPLY_STATUS && !strcmp(reply->str, "PONG")){
			result = 0;
			break;
		}else if (reply->type == REDIS_REPLY_ERROR && reply->str != NULL && strcasestr(reply->str, "loading the dataset in memory") != NULL) {
			logging(LOG_LEVEL_NOTICE, "Redis server in sync : %s\n", reply->str);
			freeReplyObject(reply);
			reply = NULL;
		}else{
			logRedisReply(reply);
			redisFree(g_rct);
			g_rct = NULL;
			result = -1;
			break;
		}
		sleep(1);
	}

	if (reply != NULL){
		freeReplyObject(reply);
		reply = NULL;
	}
	
	return result;
}

int masterRedis()
{
	redisReply   *reply;
	int result;
	
	reply = redisCommand(g_rct, "SLAVEOF NO ONE");
	if (reply != NULL && reply->type == REDIS_REPLY_STATUS && strstr(reply->str, "OK") != NULL){
		logRedisReply(reply);
		result = 0;
	}else{
		logRedisReply(reply);
		redisFree(g_rct);
		g_rct = NULL;
		result = -1;
	}
	if (reply != NULL){
		freeReplyObject(reply);
		reply = NULL;
	}

	return result;
}

int slaveRedis(char const *master_ip, char const *master_port)
{	
	redisReply   *reply;
	int result;
	char cmd[60] = {'\0'};

	sprintf(cmd, "SLAVEOF %s %s", master_ip, master_port);
	reply = redisCommand(g_rct, cmd);
	if (reply != NULL && reply->type == REDIS_REPLY_STATUS && strstr(reply->str, "OK") != NULL){
		logRedisReply(reply);
		result = 0;
	}else{
		logRedisReply(reply);
		redisFree(g_rct);
		g_rct = NULL;
		result = -1;
	}
	if (reply != NULL){
		freeReplyObject(reply);
		reply = NULL;
	}

	return result;
}
