#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <syslog.h>
#include <errno.h>
#include "zwf/zoo-watchdog.h"
#include "zwf/config.h"
#include "redis_cmd.h"

static char const *g_redis_ip = NULL;
static int g_redis_port = 0;
static char g_redis_zk_path[80];

static int g_daemon_mode = 0;

static int redisHeartbeat(struct ZooWatchdog *zwf)
{
	static int s_edge_trigger = 0;

	if (connectRedisServer(g_redis_ip, g_redis_port) != 0)
		goto FAILURE;	
	
	if (pingRedis() != 0)
		goto FAILURE;
	
	if (s_edge_trigger == 0){
		logging(LOG_LEVEL_NOTICE, "the status of redis server %s : Connected\n", g_redis_ip);
		logging(LOG_LEVEL_NOTICE, "the master, at that point, is : %s\n", 
				(*(zwf->current_leader) != '\0') ? zwf->current_leader : "No leader");
		s_edge_trigger = 1;
	}
	return 1;

FAILURE:
	logging(LOG_LEVEL_NOTICE, "the status of redis server %s : Out of connection\n", g_redis_ip);
	logging(LOG_LEVEL_NOTICE, "the master, at that point, is : %s\n", 
			(*(zwf->current_leader) != '\0') ? zwf->current_leader : "No leader");
	s_edge_trigger = 0;
	return 0;
}

static int redisFailover(struct ZooWatchdog *zwf, char const *leader_path)
{
	static char s_ip_port[60]; 
	
	char *begin, *end;
	char *master_ip, *master_port;

	begin = strrchr(leader_path, '/') + 1;
	end   = strrchr(leader_path, '-');
	strncpy(s_ip_port, begin, (end - begin));
	*(s_ip_port + (end - begin)) = '\0';
	master_ip = s_ip_port;
	master_port = strrchr(s_ip_port, ':');
	*(master_port++) = '\0';
	
	if (connectRedisServer(g_redis_ip, g_redis_port) != 0){
		logging(LOG_LEVEL_ERR, "can't connect to the redis server %s:%i\n", g_redis_ip, g_redis_port);
		goto FAILURE;	
	}
	
	if (!strcmp(zwf->node_path_plus_seq, leader_path)){
		if (masterRedis() != 0){
			logging(LOG_LEVEL_ERR, "can't switch the redis server %s:%i as a master\n", g_redis_ip, g_redis_port);
			goto FAILURE;
		}
	}else{
		if (slaveRedis(master_ip, master_port) != 0){
			logging(LOG_LEVEL_ERR, "can't switch the redis server %s:%i as a slave of %s:%s\n", g_redis_ip, g_redis_port, master_ip, master_port);
			goto FAILURE;
		}
	}

	logging(LOG_LEVEL_NOTICE, "redis master/slave switch succeeds and new master is %s\n", master_ip);
	return 0;

FAILURE:
	logging(LOG_LEVEL_ERR, "redis master/slave swtich fails.\n");
	return -1;
}

static void show_help_info()
{
	printf("Usage: redis-zoo-watchdog [-h | --help | -d | --daemon] REDISIP:REDISPORT ZKDIR\n\n"
		   "Description                                     \n"
		   "    Monitor the redis server at REDISIP:REDISPORT and register its existence\n"
		   "    with the zookeeper where the ZKDIR is a registration directory.\n\n"
		   "    -h, --help              :  show help manual.\n\n"
		   "    -c, --core              :  produce a core dump file when crashing.\n\n"
		   "    -d, --daemon            :  run as a daemon. \n\n"
		   "    -f, --conf=FILE         :  specify configuration file. \n\n");
}

static void enableCoreDump(void)
{
	struct rlimit rlimit;
	
	memset(&rlimit, 0, sizeof(struct rlimit));
	rlimit.rlim_cur = RLIM_INFINITY;
	rlimit.rlim_max = RLIM_INFINITY;

	if (setrlimit(RLIMIT_CORE, &rlimit))
	{
		fprintf(stderr, "can not enable coredump file.\n");
		exit(1);
	}
}

static void daemonize(char const *cmd)
{
	int fd0, fd1, fd2;
	pid_t pid;
	struct rlimit rlimit;

	umask(0);

	if(getrlimit(RLIMIT_NOFILE, &rlimit) < 0){
		fprintf(stderr, "%s : can not get file limit.\n", cmd);
		exit(1);
	}

	if ((pid = fork()) < 0){
		fprintf(stderr, "%s : can not fork.\n", cmd);
		exit(1);
	} else if (pid != 0){  /* parent process */
		exit(0);
	}
	setsid();

	/*	
	 * if (chdir("/") < 0){
	 * 	fprintf(stderr, "%s : can not change directory to /\n", cmd);
	 *	exit(1);
	 * }
	 */
	
	if (rlimit.rlim_max == RLIM_INFINITY)
		rlimit.rlim_max = 1024;
	for (int i = 0; i < rlimit.rlim_max; i ++){
		close(i);
	}

	fd0 = open("/dev/null", O_RDWR);
	fd1 = dup(0);
	fd2 = dup(0);
	if (fd0 != 0 || fd1 != 1 || fd2 != 2){
		syslog(LOG_ERR, "%s : unexpected file descriptors after daemonizing %d %d %d\n", cmd, fd0, fd1, fd2);
		exit(1);
	}

	syslog(LOG_INFO, "%s starts running as a daemon\n", cmd);
}

static void processCmd(int argc, char *argv[])
{
	static struct option longOptions[] = {
		{"help",    no_argument,       NULL, 'h'},
		{"daemon",  no_argument,       NULL, 'd'},
		{"core",    no_argument,       NULL, 'c'},
		{"conf",    required_argument, NULL, 'f'},
		{0,         0,                 0,     0 }
	};

	char *separator;
	char slash;
	int option;

	opterr = 0;
	for ( ; ; ){
		int longOptIndex = 0;
		option = getopt_long(argc, argv, "hdcf:", longOptions, &longOptIndex);

		if (option == -1)
			break;

		if (option == 'h'){
			show_help_info();
			exit(0);
		}

		if (option == 'd'){
			g_daemon_mode = 1;
			setLogCastType(LOG_UNICAST);
			continue;
		}

		if (option == 'c'){
			enableCoreDump();
			continue;
		}

		if (option == 'f'){
			g_conf_file = strdup(optarg);
			if (g_conf_file == NULL) {
				fprintf(stderr, "can not specify configuration file because of out of memory\n");
				exit(1);
			}
			continue;
		}

		fprintf(stderr, "Invalid input arguments/options.\n");
		goto ERROR;
	}

	if ((argc - optind) != 2){
		goto ERROR;
	}
	separator = strrchr(argv[optind], ':');
	if (separator == NULL){
		fprintf(stderr, "Invalid address : %s\n", argv[optind]);
		goto ERROR;
	}
	g_redis_ip = strndup(argv[optind], (separator - argv[optind]));
	g_redis_port = strtol(++separator, NULL, 10);
	
	slash = *(argv[optind + 1] + strlen(argv[optind + 1]) - 1);
	sprintf(g_redis_zk_path, "%s%s%s:%d", argv[optind + 1], (slash == '/') ? "": "/", g_redis_ip, g_redis_port);

	return;

ERROR:
	show_help_info();
	exit(1);
}


int main(int argc, char *argv[])
{
	struct ZooWatchdog *zwf;
	int rc;

	signal(SIGPIPE, SIG_IGN);
	
	processCmd(argc, argv);
	zooWatchdogConfig();

	if (g_daemon_mode == 1)
		daemonize(argv[0]);

	zwf = createZooWatchdog();
	rc = zwf->init(zwf, g_redis_zk_path, NULL, -1, NULL);
	if (rc != 0){
		if (g_daemon_mode == 0)
			fprintf(stderr, "%s can not be initialized : %s\n", argv[0], strerror(errno));
		else
			syslog(LOG_ERR, "%s can not be initialized : %s\n", argv[0], strerror(errno));
		exit(1);
	}
	zwf->heartbeat = redisHeartbeat;
	zwf->failover  = redisFailover;
	zwf->run(zwf);

	return EXIT_SUCCESS;
}
