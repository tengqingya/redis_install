#!/bin/bash

export LD_LIBRARY_PATH=./lib
./redis-zoo-watchdog.elf $@
